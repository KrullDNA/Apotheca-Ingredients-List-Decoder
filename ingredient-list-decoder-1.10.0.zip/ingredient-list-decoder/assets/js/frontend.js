/**
 * Front-end behaviour for the Ingredient List Decoder.
 *
 * Submits the form over AJAX with no page reload: it shows the loading region,
 * posts the form (nonce and all) to admin-ajax, and drops the returned HTML
 * fragment into the results region. It also keeps a live character count, moves
 * focus to the result so keyboard and screen-reader users are taken to it, and
 * clears everything when "start again" is pressed.
 *
 * No wording lives here — every visible string is rendered server-side from the
 * one PHP phrases file. The only text this file composes is the character count,
 * whose template comes through from PHP with %used% and %max% tokens.
 */
( function () {
	'use strict';

	var settings = window.ILD_Frontend || {};

	/* -------------------------------------------------------------------
	 * Fresh nonces for cached pages.
	 *
	 * The tool's page HTML is frequently served from a full-page cache
	 * (LiteSpeed, WP Rocket, Cloudflare), so the nonce baked into the form can
	 * be long expired by the time someone uses it — which the server rejects.
	 * We fetch a live nonce from an uncached endpoint on load and write it into
	 * the form fields, and make sure that fetch has resolved before we submit.
	 * ----------------------------------------------------------------- */
	var freshNonces = {};
	var noncePromise = null;

	function setNonceFields( selector, value ) {
		if ( ! value ) {
			return;
		}
		var fields = document.querySelectorAll( selector );
		Array.prototype.forEach.call( fields, function ( field ) {
			field.value = value;
		} );
	}

	function applyNonces() {
		setNonceFields( 'input[name="ild_nonce"]', freshNonces.analyse );
		setNonceFields( 'input[name="ild_transcribe_nonce"]', freshNonces.transcribe );
		setNonceFields( 'input[name="ild_gate_nonce"]', freshNonces.gate );
	}

	function ensureNonces() {
		if ( noncePromise ) {
			return noncePromise;
		}
		if ( ! settings.ajaxUrl || ! settings.refreshAction ) {
			noncePromise = Promise.resolve();
			return noncePromise;
		}

		var body = new URLSearchParams();
		body.append( 'action', settings.refreshAction );

		noncePromise = fetch( settings.ajaxUrl, {
			method: 'POST',
			credentials: 'same-origin',
			headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
			body: body.toString()
		} )
			.then( function ( response ) { return response.json(); } )
			.then( function ( payload ) {
				if ( payload && payload.success && payload.data ) {
					freshNonces = payload.data;
					applyNonces();
				}
			} )
			.catch( function () { /* Fall back to the embedded nonce. */ } );

		return noncePromise;
	}

	/**
	 * Find the tool wrapper a given element belongs to.
	 *
	 * @param {Element} el The starting element.
	 * @return {Element|null} The .ild-tool wrapper, or null.
	 */
	function toolOf( el ) {
		return el && el.closest ? el.closest( '.ild-tool' ) : null;
	}

	/**
	 * Update the live character count under a textarea.
	 *
	 * @param {HTMLTextAreaElement} textarea The list textarea.
	 */
	function updateCount( textarea ) {
		var tool = toolOf( textarea );
		if ( ! tool ) {
			return;
		}

		var counter = tool.querySelector( '[data-ild-charcount]' );
		if ( ! counter ) {
			return;
		}

		var max = parseInt( textarea.getAttribute( 'maxlength' ), 10 ) || 0;
		var used = textarea.value.length;

		var template = settings.charCount || '%used% / %max%';
		counter.textContent = template
			.replace( '%used%', String( used ) )
			.replace( '%max%', String( max ) );
	}

	/**
	 * Reset a tool to its starting state: clear the field, the count, the result
	 * and any messages, then return focus to the textarea.
	 *
	 * @param {Element} tool The .ild-tool wrapper.
	 */
	function restart( tool ) {
		if ( ! tool ) {
			return;
		}

		var textarea = tool.querySelector( '.ild-textarea' );
		var product = tool.querySelector( '.ild-product' );
		var results = tool.querySelector( '.ild-results' );
		var netError = tool.querySelector( '.ild-error--network' );

		if ( textarea ) {
			textarea.value = '';
			updateCount( textarea );
		}
		if ( product ) {
			product.value = '';
		}
		if ( results ) {
			results.innerHTML = '';
		}
		if ( netError ) {
			netError.hidden = true;
		}
		if ( textarea ) {
			textarea.focus();
		}
	}

	// Keep the character count current as the visitor types or pastes.
	document.addEventListener( 'input', function ( event ) {
		var target = event.target;
		if ( target && target.classList && target.classList.contains( 'ild-textarea' ) ) {
			updateCount( target );
		}
	} );

	// Prime the count for every tool already on the page, and fetch a live nonce
	// straight away so a cached page can still submit.
	document.addEventListener( 'DOMContentLoaded', function () {
		var boxes = document.querySelectorAll( '.ild-tool .ild-textarea' );
		Array.prototype.forEach.call( boxes, updateCount );

		if ( document.querySelector( '.ild-tool' ) ) {
			ensureNonces();
		}
	} );

	// "Start again" clears the tool. The button only exists inside a result.
	document.addEventListener( 'click', function ( event ) {
		var target = event.target;
		if ( ! target || ! target.closest ) {
			return;
		}
		var button = target.closest( '[data-ild-restart]' );
		if ( button ) {
			event.preventDefault();
			restart( toolOf( button ) );
			return;
		}

		// "Apply to ingredient list" on a "did you mean…" row: swap the mistyped
		// token for the suggested INCI name in the textarea, then read again.
		var apply = target.closest( '[data-ild-apply]' );
		if ( apply ) {
			event.preventDefault();
			applySuggestion( apply );
		}
	} );

	/**
	 * Escape a string for safe use inside a regular expression.
	 *
	 * @param {string} str The literal string.
	 * @return {string}
	 */
	function escapeRegExp( str ) {
		return String( str ).replace( /[.*+?^${}()|[\]\\]/g, '\\$&' );
	}

	/**
	 * Replace a mistyped token with a suggested name and re-read the list.
	 *
	 * The suggestion row carries the token as it was typed and the INCI name to
	 * put in its place. We swap the first case-insensitive occurrence in the
	 * textarea, refresh the count, and submit the form so the corrected list is
	 * read straight away.
	 *
	 * @param {Element} apply The clicked apply control.
	 */
	function applySuggestion( apply ) {
		var tool = toolOf( apply );
		if ( ! tool ) {
			return;
		}

		var original = apply.getAttribute( 'data-original' ) || '';
		var replacement = apply.getAttribute( 'data-replacement' ) || '';
		var textarea = tool.querySelector( '.ild-textarea' );
		if ( ! textarea || '' === original || '' === replacement ) {
			return;
		}

		// Swap only the first occurrence, matched without regard to case so a
		// lower-cased paste is corrected too. A word boundary is avoided on purpose
		// — INCI tokens can carry brackets, hyphens and digits.
		var pattern = new RegExp( escapeRegExp( original ), 'i' );
		if ( pattern.test( textarea.value ) ) {
			textarea.value = textarea.value.replace( pattern, replacement );
		}
		updateCount( textarea );

		var form = tool.querySelector( '.ild-form' );
		if ( form ) {
			if ( form.requestSubmit ) {
				form.requestSubmit();
			} else {
				form.dispatchEvent( new Event( 'submit', { cancelable: true, bubbles: true } ) );
			}
		}
	}

	/* -------------------------------------------------------------------
	 * Photo route: upload/camera → convert & resize → transcribe → verify.
	 * The image is prepared in the browser and read on the server; nothing
	 * is analysed until the visitor confirms the transcription.
	 * ----------------------------------------------------------------- */

	// Remember each tool's current thumbnail URL so it can be revoked.
	var thumbUrls = new WeakMap();

	// Keep the prepared JPEG per tool, so the optional "read it more accurately"
	// button can re-send the same image without asking for it again.
	var preparedBlobs = new WeakMap();

	/**
	 * Look up a photo-handling message by key, with a sensible fallback.
	 *
	 * @param {string} key The message id.
	 * @return {string}
	 */
	function photoMsg( key ) {
		var m = settings.photoMessages || {};
		return m[ key ] || m.network || '';
	}

	/**
	 * Draw an image source onto a canvas, scaled down, and export it as JPEG.
	 * Works for JPEG/PNG everywhere, and for HEIC on browsers that can decode
	 * it (Safari, i.e. most iPhones). Resolves null if the source can't decode.
	 *
	 * @param {Blob} src     The image blob or file.
	 * @param {number} maxDim The longest-edge cap in pixels.
	 * @param {number} quality JPEG quality 0–1.
	 * @return {Promise<Blob|null>}
	 */
	function drawToCanvas( src, maxDim, quality ) {
		return new Promise( function ( resolve ) {
			var url = URL.createObjectURL( src );
			var img = new Image();
			img.onload = function () {
				var w = img.naturalWidth;
				var h = img.naturalHeight;
				if ( ! w || ! h ) {
					URL.revokeObjectURL( url );
					resolve( null );
					return;
				}
				var scale = Math.min( 1, maxDim / Math.max( w, h ) );
				var canvas = document.createElement( 'canvas' );
				canvas.width = Math.round( w * scale );
				canvas.height = Math.round( h * scale );
				canvas.getContext( '2d' ).drawImage( img, 0, 0, canvas.width, canvas.height );
				URL.revokeObjectURL( url );
				canvas.toBlob( function ( blob ) { resolve( blob ); }, 'image/jpeg', quality );
			};
			img.onerror = function () {
				URL.revokeObjectURL( url );
				resolve( null );
			};
			img.src = url;
		} );
	}

	// heic2any is loaded on demand, only when a HEIC can't be decoded natively.
	var heicPromise = null;
	function loadHeic2any() {
		if ( window.heic2any ) {
			return Promise.resolve();
		}
		if ( heicPromise ) {
			return heicPromise;
		}
		if ( ! settings.heicUrl ) {
			return Promise.reject( new Error( 'no-heic-url' ) );
		}
		heicPromise = new Promise( function ( resolve, reject ) {
			var s = document.createElement( 'script' );
			s.src = settings.heicUrl;
			s.onload = resolve;
			s.onerror = reject;
			document.head.appendChild( s );
		} );
		return heicPromise;
	}

	/**
	 * Convert a HEIC file to a JPEG blob using heic2any, loaded on demand.
	 *
	 * @param {File} file The HEIC file.
	 * @return {Promise<Blob|null>}
	 */
	function convertHeic( file ) {
		return loadHeic2any()
			.then( function () {
				if ( ! window.heic2any ) {
					return null;
				}
				return window.heic2any( { blob: file, toType: 'image/jpeg', quality: 0.9 } );
			} )
			.then( function ( out ) {
				return Array.isArray( out ) ? out[ 0 ] : out;
			} )
			.catch( function () {
				return null;
			} );
	}

	// Tesseract.js is loaded on demand, only when a photo is actually read. It
	// does the free reading entirely in the browser — the photo never leaves the
	// device on this path.
	var ocrPromise = null;
	function loadOcrEngine() {
		if ( window.Tesseract ) {
			return Promise.resolve();
		}
		if ( ocrPromise ) {
			return ocrPromise;
		}
		if ( ! settings.tesseractUrl ) {
			return Promise.reject( new Error( 'no-ocr-url' ) );
		}
		ocrPromise = new Promise( function ( resolve, reject ) {
			var s = document.createElement( 'script' );
			s.src = settings.tesseractUrl;
			s.onload = resolve;
			s.onerror = reject;
			document.head.appendChild( s );
		} );
		return ocrPromise;
	}

	/**
	 * Tidy raw OCR output: trim, drop empty lines, and collapse runs of blank
	 * lines. Commas and newlines are both treated as separators downstream, so no
	 * more than this is needed — the visitor checks and corrects it next.
	 *
	 * @param {string} text The raw recognised text.
	 * @return {string}
	 */
	function tidyOcr( text ) {
		return String( text || '' )
			.replace( /\r/g, '' )
			.split( '\n' )
			.map( function ( line ) { return line.replace( /[ \t]+/g, ' ' ).trim(); } )
			.filter( function ( line ) { return '' !== line; } )
			.join( '\n' )
			.trim();
	}

	/**
	 * Whether one token is OCR noise rather than an ingredient name.
	 *
	 * @param {string} t A single token.
	 * @return {boolean}
	 */
	function isNoiseToken( t ) {
		if ( /\bci\s*\d/i.test( t ) ) {
			return false; // A colour-index code (CI 77491) is real.
		}
		var letters = ( t.match( /[A-Za-zÀ-ɏ]/g ) || [] ).length;
		var solid = t.replace( /\s+/g, '' );
		if ( 0 === letters ) {
			return true; // No letters at all: "4 : |", "|", "N)".
		}
		if ( solid.length <= 2 ) {
			return true; // Tiny fragment: "nr", "on", "o".
		}
		if ( letters < 2 ) {
			return true;
		}
		if ( ( letters / solid.length ) < 0.4 && ! /\d{3,}/.test( t ) ) {
			return true; // Mostly symbols/digits and not a colour code.
		}
		return false;
	}

	/**
	 * Strip runs of noise words from the start and end of one token — the stray
	 * "N)", "4", ":", "|" an OCR read leaves glued to a name — while keeping the
	 * real words in the middle. Colour-index codes (CI 77491) are left alone.
	 *
	 * @param {string} t A single token.
	 * @return {string}
	 */
	function trimEdgeJunkWords( t ) {
		if ( /\bci\s*\d/i.test( t ) ) {
			return t;
		}
		function junk( w ) {
			var bare = w.replace( /[^0-9A-Za-zÀ-ɏ]/g, '' );
			if ( '' === bare ) {
				return true; // Pure punctuation: ":", "|".
			}
			if ( /^\d{1,2}$/.test( bare ) ) {
				return true; // A stray one- or two-digit number.
			}
			if ( 1 === ( bare.match( /[A-Za-zÀ-ɏ]/g ) || [] ).length && bare.length <= 2 ) {
				return true; // A single letter, e.g. "N)", "o".
			}
			return false;
		}
		var words = t.split( ' ' );
		while ( words.length && junk( words[ 0 ] ) ) {
			words.shift();
		}
		while ( words.length && junk( words[ words.length - 1 ] ) ) {
			words.pop();
		}
		return words.join( ' ' );
	}

	/**
	 * Whether a bracketed group is a description to drop, rather than a common
	 * name to keep. "(Plant based surfactant)" is a description; "(Aqua)",
	 * "(Shea)", "(Water)" are common names that help a token match, so are kept.
	 *
	 * @param {string} inner The text inside the brackets.
	 * @return {boolean}
	 */
	function isDescriptiveBracket( inner ) {
		var s = String( inner || '' ).trim();
		if ( '' === s ) {
			return false;
		}
		if ( s.split( /\s+/ ).length >= 3 ) {
			return true; // Three or more words reads as a description.
		}
		return /\b(based|derived|natural|naturally|surfactant|emulsifier|humectant|preservative|plant|conditioner|conditioning|thickener|cleanser|from|origin|blend|complex|extract\s+of)\b/i.test( s );
	}

	/**
	 * Tidy a read (from a photo, or pasted) for the verification box: drop a
	 * leading "ingredients" label and anything before it, rejoin names split
	 * across lines when commas separate the list, remove descriptive brackets
	 * that follow a name — "Coco-Glucoside (Plant based surfactant)" — while
	 * keeping a leading common name like "(Jojoba) Seed Oil", trim stray edge
	 * punctuation, and drop obvious OCR noise. The visitor still checks the
	 * result before it is read.
	 *
	 * @param {string} text The raw text.
	 * @return {string}
	 */
	function cleanReadText( text ) {
		var s = String( text || '' );

		// Drop a leading label and everything before it (matches the parser).
		s = s.replace( /^[\s\S]*\bingredients?\b\s*:?\s*/i, '' );

		// When commas or semicolons separate items, a line break is a wrap inside
		// one name, so join it into a space.
		if ( /[;,]/.test( s ) ) {
			s = s.replace( /[ \t]*[\r\n]+[ \t]*/g, ' ' );
		}

		var parts = s.split( /[;,\n]+/ );
		var out = [];
		for ( var i = 0; i < parts.length; i++ ) {
			var t = parts[ i ].replace( /\s+/g, ' ' ).trim();

			// Remove a bracketed group that follows a name only when it is a
			// description ("(Plant based surfactant)"), never a short common name
			// like "(Aqua)" or "(Shea)" — those help the token match. A leading
			// bracket is always kept (it carries the name).
			t = t.replace( /(\S)\s*\(([^()]*)\)/g, function ( whole, pre, inner ) {
				return isDescriptiveBracket( inner ) ? pre : whole;
			} ).replace( /\s+/g, ' ' ).trim();

			// Drop a dangling, unclosed bracket at the end — an OCR read that lost
			// the closing bracket, e.g. "Panthenol (Pro-Vitamin".
			t = t.replace( /[([{][^)\]}]*$/, '' ).replace( /\s+/g, ' ' ).trim();

			// Drop noise words glued to the front or back of the name.
			t = trimEdgeJunkWords( t );

			// Trim stray leading/trailing punctuation (keep a leading "(" and a
			// trailing ")", "%", ".", digits and letters).
			t = t.replace( /^[^0-9A-Za-zÀ-ɏ(]+/, '' ).replace( /[^0-9A-Za-zÀ-ɏ)%.+-]+$/, '' ).trim();

			if ( '' === t || isNoiseToken( t ) ) {
				continue;
			}
			out.push( t );
		}

		return out.join( ', ' );
	}

	/**
	 * Read the text off a prepared image in the browser with Tesseract.js.
	 *
	 * @param {Blob} blob The prepared JPEG.
	 * @return {Promise<string>} The tidied text (may be empty).
	 */
	function runOcr( blob ) {
		return loadOcrEngine().then( function () {
			if ( ! window.Tesseract || ! window.Tesseract.recognize ) {
				return Promise.reject( new Error( 'no-ocr' ) );
			}
			var lang = settings.ocrLang || 'eng';
			return window.Tesseract.recognize( blob, lang ).then( function ( result ) {
				return tidyOcr( result && result.data ? result.data.text : '' );
			} );
		} );
	}

	/**
	 * Prepare a chosen file for upload: decode (converting HEIC where the
	 * browser can't), resize to the configured cap, and compress under the
	 * size limit. Resolves a JPEG blob, or null if it couldn't be prepared.
	 *
	 * @param {File} file The chosen file.
	 * @return {Promise<Blob|null>}
	 */
	function prepareImage( file ) {
		var dim = settings.maxImageDim || 1800;
		var maxBytes = settings.maxImageBytes || 0;
		var isHeic = /heic|heif/i.test( file.type ) || /\.(heic|heif)$/i.test( file.name );

		var decodable = file;

		return drawToCanvas( decodable, dim, 0.85 )
			.then( function ( blob ) {
				if ( blob || ! isHeic ) {
					return blob;
				}
				// Native decode failed on a HEIC: convert, then draw again.
				return convertHeic( file ).then( function ( converted ) {
					if ( ! converted ) {
						return null;
					}
					decodable = converted;
					return drawToCanvas( decodable, dim, 0.85 );
				} );
			} )
			.then( function ( blob ) {
				if ( ! blob ) {
					return null;
				}
				// Shrink further, by quality then dimension, to fit the cap.
				function fit( current, quality, dimension ) {
					if ( ! maxBytes || current.size <= maxBytes || quality < 0.4 ) {
						return Promise.resolve( current );
					}
					return drawToCanvas( decodable, dimension, quality ).then( function ( next ) {
						if ( ! next ) {
							return current;
						}
						return fit( next, quality - 0.15, Math.round( dimension * 0.85 ) );
					} );
				}
				return fit( blob, 0.7, dim );
			} );
	}

	/* --- Photo UI state helpers --------------------------------------- */
	function photoParts( tool ) {
		return {
			field:    tool.querySelector( '.ild-field--photo' ),
			zone:     tool.querySelector( '[data-ild-dropzone]' ),
			progress: tool.querySelector( '[data-ild-photo-progress]' ),
			status:   tool.querySelector( '[data-ild-photo-status]' ),
			error:    tool.querySelector( '[data-ild-photo-error]' ),
			verify:   tool.querySelector( '[data-ild-verify]' ),
			text:     tool.querySelector( '[data-ild-verify-text]' ),
			thumb:    tool.querySelector( '[data-ild-verify-thumb]' ),
			enhance:  tool.querySelector( '[data-ild-verify-enhance]' ),
			vstatus:  tool.querySelector( '[data-ild-verify-status]' )
		};
	}

	/**
	 * Show or clear the small status line inside the verification step.
	 *
	 * @param {Element} tool    The tool wrapper.
	 * @param {string}  message The text to show, or '' to hide it.
	 */
	function setVerifyStatus( tool, message ) {
		var p = photoParts( tool );
		if ( p.vstatus ) {
			p.vstatus.textContent = message || '';
			p.vstatus.hidden = ! message;
		}
	}

	function setUploading( tool, on ) {
		var p = photoParts( tool );
		if ( p.zone ) {
			p.zone.classList.toggle( 'is-uploading', !! on );
			if ( on ) {
				p.zone.classList.remove( 'is-error' );
			}
		}
		if ( p.progress ) {
			p.progress.hidden = ! on;
		}
		if ( p.status ) {
			p.status.hidden = ! on;
			p.status.textContent = on ? ( settings.photoReading || '' ) : '';
		}
	}

	function showPhotoError( tool, message ) {
		var p = photoParts( tool );
		setUploading( tool, false );
		if ( p.zone ) {
			p.zone.classList.add( 'is-error' );
		}
		if ( p.error ) {
			p.error.textContent = message;
			p.error.hidden = false;
		}
	}

	function clearPhotoError( tool ) {
		var p = photoParts( tool );
		if ( p.zone ) {
			p.zone.classList.remove( 'is-error' );
		}
		if ( p.error ) {
			p.error.hidden = true;
			p.error.textContent = '';
		}
	}

	/**
	 * Check a read list against the library and correct close names in place.
	 *
	 * No AI: the server runs the same fuzzy match the reader uses against the
	 * ingredient database and hands back the list with confident names snapped to
	 * their stored INCI form. The box is only updated if the person has not begun
	 * editing it in the meantime.
	 *
	 * @param {Element}             tool     The tool wrapper.
	 * @param {HTMLTextAreaElement} textarea The verify textarea.
	 * @param {string}              current  The text just placed in the textarea.
	 */
	function tidyAgainstLibrary( tool, textarea, current ) {
		if ( ! settings.tidyAction || ! settings.ajaxUrl || ! current ) {
			return;
		}

		var form = tool.querySelector( '.ild-form' );
		var nonceField = form ? form.querySelector( 'input[name="ild_nonce"]' ) : null;
		var nonce = freshNonces.analyse || ( nonceField ? nonceField.value : '' );

		var body = new URLSearchParams();
		body.append( 'action', settings.tidyAction );
		body.append( 'ild_list', current );
		if ( nonce ) {
			body.append( 'ild_nonce', nonce );
		}

		setVerifyStatus( tool, settings.photoMatching || '' );

		fetch( settings.ajaxUrl, {
			method: 'POST',
			credentials: 'same-origin',
			headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
			body: body.toString()
		} )
			.then( function ( response ) { return response.json(); } )
			.then( function ( payload ) {
				setVerifyStatus( tool, '' );
				if ( payload && payload.success && payload.data && typeof payload.data.list === 'string' && payload.data.list ) {
					// Only replace if the person has not edited the box since.
					if ( textarea.value === current ) {
						textarea.value = payload.data.list;
					}
				}
			} )
			.catch( function () { setVerifyStatus( tool, '' ); } );
	}

	function showVerify( tool, text, thumbUrl ) {
		var p = photoParts( tool );
		setVerifyStatus( tool, '' );
		if ( p.enhance ) {
			p.enhance.disabled = false;
		}
		if ( p.text ) {
			// Tidy the read before showing it, so the box is clean to check…
			var cleaned = cleanReadText( text );
			p.text.value = cleaned;
			// …then check the names against the library (no AI — a fuzzy match on
			// the database) and correct close reads in place.
			tidyAgainstLibrary( tool, p.text, cleaned );
		}
		if ( p.thumb && thumbUrl ) {
			var old = thumbUrls.get( tool );
			if ( old ) {
				URL.revokeObjectURL( old );
			}
			thumbUrls.set( tool, thumbUrl );
			p.thumb.src = thumbUrl;
		}
		if ( p.field ) {
			p.field.hidden = true;
		}
		if ( p.verify ) {
			p.verify.hidden = false;
			if ( p.text ) {
				p.text.focus();
			}
		}
	}

	function hideVerify( tool, keepField ) {
		var p = photoParts( tool );
		if ( p.verify ) {
			p.verify.hidden = true;
		}
		if ( p.field && ! keepField ) {
			p.field.hidden = false;
		}
		setVerifyStatus( tool, '' );
		// The prepared image is no longer needed once we leave the verify step.
		preparedBlobs.delete( tool );
		var old = thumbUrls.get( tool );
		if ( old ) {
			URL.revokeObjectURL( old );
			thumbUrls.delete( tool );
		}
	}

	/**
	 * Send a prepared image to the paid transcription endpoint (the more accurate
	 * AI reading). Resolves the transcribed text; rejects with an Error whose
	 * userMessage carries the server's own message.
	 *
	 * @param {Element} tool The tool wrapper.
	 * @param {Blob}    blob The prepared JPEG.
	 * @return {Promise<string>}
	 */
	function serverTranscribe( tool, blob ) {
		var form = tool.querySelector( '.ild-form' );
		var nonceField = form ? form.querySelector( 'input[name="ild_transcribe_nonce"]' ) : null;

		var data = new FormData();
		data.append( 'action', settings.transcribeAction );
		// Prefer the freshly fetched nonce over the (possibly cached) form one.
		var transcribeNonce = freshNonces.transcribe || ( nonceField ? nonceField.value : '' );
		if ( transcribeNonce ) {
			data.append( 'ild_transcribe_nonce', transcribeNonce );
		}
		data.append( 'ild_image', blob, 'ingredients.jpg' );

		return fetch( settings.ajaxUrl, {
			method: 'POST',
			credentials: 'same-origin',
			body: data
		} )
			.then( function ( response ) { return response.json(); } )
			.then( function ( payload ) {
				if ( payload && payload.success && payload.data && typeof payload.data.text === 'string' ) {
					return payload.data.text;
				}
				var err = new Error( 'server' );
				err.userMessage = ( payload && payload.data && payload.data.message ) ? payload.data.message : photoMsg( 'read_failed' );
				throw err;
			} );
	}

	/**
	 * When free reading finds nothing (or the engine fails) and an API key is
	 * configured, fall back to the paid AI reading of the same prepared image.
	 *
	 * @param {Element} tool     The tool wrapper.
	 * @param {Blob}    blob     The prepared JPEG.
	 * @param {string}  thumbUrl An object URL for the thumbnail.
	 */
	function serverFallback( tool, blob, thumbUrl ) {
		serverTranscribe( tool, blob )
			.then( function ( text ) {
				setUploading( tool, false );
				text = ( text || '' ).trim();
				if ( text ) {
					showVerify( tool, text, thumbUrl );
				} else {
					URL.revokeObjectURL( thumbUrl );
					showPhotoError( tool, photoMsg( 'no_text' ) );
				}
			} )
			.catch( function ( err ) {
				setUploading( tool, false );
				URL.revokeObjectURL( thumbUrl );
				showPhotoError( tool, ( err && err.userMessage ) ? err.userMessage : photoMsg( 'network' ) );
			} );
	}

	/**
	 * Read a prepared image: free, in the browser, by default. If it yields
	 * nothing (or can't run) and an API key is set, fall back to the AI reading.
	 *
	 * @param {Element} tool     The tool wrapper.
	 * @param {Blob}    blob     The prepared JPEG.
	 * @param {string}  thumbUrl An object URL for the thumbnail.
	 */
	function readPhoto( tool, blob, thumbUrl ) {
		runOcr( blob )
			.then( function ( text ) {
				if ( text ) {
					setUploading( tool, false );
					showVerify( tool, text, thumbUrl );
					return;
				}
				// Nothing read for free. Try the AI reading if it's available.
				if ( settings.photoEnabled ) {
					serverFallback( tool, blob, thumbUrl );
					return;
				}
				setUploading( tool, false );
				URL.revokeObjectURL( thumbUrl );
				showPhotoError( tool, photoMsg( 'no_text' ) );
			} )
			.catch( function () {
				// The free engine couldn't run. Fall back to AI if available.
				if ( settings.photoEnabled ) {
					serverFallback( tool, blob, thumbUrl );
					return;
				}
				setUploading( tool, false );
				URL.revokeObjectURL( thumbUrl );
				showPhotoError( tool, photoMsg( 'read_failed' ) );
			} );
	}

	/**
	 * Validate and process a chosen file end to end.
	 *
	 * @param {Element} tool The tool wrapper.
	 * @param {File}    file The chosen file.
	 */
	function processFile( tool, file ) {
		if ( ! file ) {
			return;
		}
		clearPhotoError( tool );

		if ( settings.ocrEnabled === false ) {
			showPhotoError( tool, photoMsg( 'not_ready' ) );
			return;
		}

		var okType = /image\/(jpeg|png|heic|heif)/i.test( file.type ) || /\.(jpe?g|png|heic|heif)$/i.test( file.name );
		if ( ! okType ) {
			showPhotoError( tool, photoMsg( 'wrong_type' ) );
			return;
		}
		if ( settings.maxImageBytes && file.size > settings.maxImageBytes ) {
			showPhotoError( tool, photoMsg( 'too_large' ) );
			return;
		}

		setUploading( tool, true );
		prepareImage( file )
			.then( function ( blob ) {
				if ( ! blob ) {
					setUploading( tool, false );
					showPhotoError( tool, photoMsg( 'convert_failed' ) );
					return;
				}
				// Keep the prepared image so the verify step's "read it more
				// accurately" button can re-send it without a re-pick.
				preparedBlobs.set( tool, blob );
				readPhoto( tool, blob, URL.createObjectURL( blob ) );
			} )
			.catch( function () {
				setUploading( tool, false );
				showPhotoError( tool, photoMsg( 'convert_failed' ) );
			} );
	}

	// A file chosen through the picker or the camera.
	document.addEventListener( 'change', function ( event ) {
		var input = event.target;
		if ( ! input || ! input.matches || ! input.matches( '[data-ild-photo]' ) ) {
			return;
		}
		var tool = toolOf( input );
		if ( tool && input.files && input.files.length ) {
			processFile( tool, input.files[ 0 ] );
		}
		// Reset so choosing the same file again still fires a change.
		input.value = '';
	} );

	// Drag and drop onto the dropzone.
	document.addEventListener( 'dragover', function ( event ) {
		var zone = event.target && event.target.closest ? event.target.closest( '[data-ild-dropzone]' ) : null;
		if ( zone ) {
			event.preventDefault();
			zone.classList.add( 'is-dragover' );
		}
	} );
	document.addEventListener( 'dragleave', function ( event ) {
		var zone = event.target && event.target.closest ? event.target.closest( '[data-ild-dropzone]' ) : null;
		if ( zone && ! zone.contains( event.relatedTarget ) ) {
			zone.classList.remove( 'is-dragover' );
		}
	} );
	document.addEventListener( 'drop', function ( event ) {
		var zone = event.target && event.target.closest ? event.target.closest( '[data-ild-dropzone]' ) : null;
		if ( ! zone ) {
			return;
		}
		event.preventDefault();
		zone.classList.remove( 'is-dragover' );
		var tool = toolOf( zone );
		if ( tool && event.dataTransfer && event.dataTransfer.files && event.dataTransfer.files.length ) {
			processFile( tool, event.dataTransfer.files[ 0 ] );
		}
	} );

	// Confirm the transcription, or retake.
	document.addEventListener( 'click', function ( event ) {
		var target = event.target;
		if ( ! target || ! target.closest ) {
			return;
		}

		var confirm = target.closest( '[data-ild-verify-confirm]' );
		if ( confirm ) {
			event.preventDefault();
			var tool = toolOf( confirm );
			if ( ! tool ) {
				return;
			}
			var parts = photoParts( tool );
			var textarea = tool.querySelector( '.ild-textarea' );
			if ( textarea && parts.text ) {
				textarea.value = parts.text.value;
				updateCount( textarea );
			}
			hideVerify( tool, true );
			var form = tool.querySelector( '.ild-form' );
			if ( form ) {
				if ( form.requestSubmit ) {
					form.requestSubmit();
				} else {
					form.dispatchEvent( new Event( 'submit', { cancelable: true, bubbles: true } ) );
				}
			}
			return;
		}

		// "Read it more accurately": re-read the same photo with the paid AI, and
		// replace the transcription in place. Only present when a key is set.
		var enhance = target.closest( '[data-ild-verify-enhance]' );
		if ( enhance ) {
			event.preventDefault();
			if ( enhance.disabled ) {
				return;
			}
			var etool = toolOf( enhance );
			if ( ! etool ) {
				return;
			}
			var eblob = preparedBlobs.get( etool );
			if ( ! eblob ) {
				return;
			}
			var eparts = photoParts( etool );
			enhance.disabled = true;
			setVerifyStatus( etool, settings.photoEnhancing || '' );
			serverTranscribe( etool, eblob )
				.then( function ( text ) {
					text = cleanReadText( text );
					if ( text && eparts.text ) {
						eparts.text.value = text;
					}
					setVerifyStatus( etool, '' );
					enhance.disabled = false;
				} )
				.catch( function ( err ) {
					setVerifyStatus( etool, ( err && err.userMessage ) ? err.userMessage : photoMsg( 'enhance_failed' ) );
					enhance.disabled = false;
				} );
			return;
		}

		var retake = target.closest( '[data-ild-verify-retake]' );
		if ( retake ) {
			event.preventDefault();
			var t = toolOf( retake );
			if ( t ) {
				var pp = photoParts( t );
				if ( pp.text ) {
					pp.text.value = '';
				}
				clearPhotoError( t );
				hideVerify( t );
			}
		}
	} );

	/* -------------------------------------------------------------------
	 * Email gate: enable the button once consent is ticked, submit the
	 * gate, and reveal the breakdown in place.
	 * ----------------------------------------------------------------- */

	/* -------------------------------------------------------------------
	 * Remembered email.
	 *
	 * The address is kept only in this browser (localStorage), never in a
	 * cookie, so a returning visitor is shown the email their copy will go to
	 * with a link to change it — but nothing about them travels with the page.
	 * ----------------------------------------------------------------- */
	var EMAIL_STORE_KEY = 'ild_email';
	var CONSENT_STORE_KEY = 'ild_consent';

	function rememberedEmail() {
		try {
			return window.localStorage.getItem( EMAIL_STORE_KEY ) || '';
		} catch ( e ) {
			return '';
		}
	}

	function rememberEmail( email ) {
		try {
			if ( email ) {
				window.localStorage.setItem( EMAIL_STORE_KEY, email );
			}
		} catch ( e ) { /* Storage unavailable — carry on without it. */ }
	}

	// Whether this browser has a record of the visitor ticking consent before.
	function rememberedConsent() {
		try {
			return 'yes' === window.localStorage.getItem( CONSENT_STORE_KEY );
		} catch ( e ) {
			return false;
		}
	}

	function rememberConsent() {
		try {
			window.localStorage.setItem( CONSENT_STORE_KEY, 'yes' );
		} catch ( e ) { /* Storage unavailable — carry on without it. */ }
	}

	/**
	 * Put a gate form into "remembered email" mode when this device knows an
	 * address: fill the field, hide it, and show "we'll send it to X" with the
	 * change link. Leaves the form untouched when no address is remembered.
	 *
	 * @param {HTMLFormElement} form The gate form.
	 */
	function initGateForm( form ) {
		if ( ! form ) {
			return;
		}
		var stored = rememberedEmail();
		var known = form.querySelector( '[data-ild-gate-known]' );
		var knownEmail = form.querySelector( '[data-ild-gate-known-email]' );
		var field = form.querySelector( '.ild-gate__field' );
		var input = form.querySelector( '.ild-gate__email' );

		if ( ! stored || ! known || ! knownEmail || ! field || ! input ) {
			return;
		}

		input.value = stored;
		knownEmail.textContent = stored;
		known.hidden = false;
		field.hidden = true;

		// If this device also remembers a prior opt-in, drop the consent box: the
		// visitor has ticked it before, so a resend they asked for does not re-ask.
		// Consent is still sent and recorded server-side. Changing the address
		// brings the box back (handled by the change link).
		if ( rememberedConsent() ) {
			applyRememberedConsent( form, true );
		}
	}

	/**
	 * Toggle a gate form between "already opted in" and "needs consent".
	 *
	 * @param {HTMLFormElement} form The gate form.
	 * @param {boolean}         on   True to drop the consent box, false to restore it.
	 */
	function applyRememberedConsent( form, on ) {
		var consentBlock = form.querySelector( '.ild-gate__consent' );
		var checkbox = form.querySelector( '[data-ild-gate-consent]' );
		var note = form.querySelector( '[data-ild-gate-note]' );
		var submit = form.querySelector( '[data-ild-gate-submit]' );
		var optedin = form.querySelector( '[data-ild-gate-optedin]' );

		if ( consentBlock ) {
			consentBlock.hidden = on;
		}
		if ( checkbox ) {
			// Carry the consent through on send (the record is kept server-side).
			checkbox.checked = on;
		}
		if ( note ) {
			note.hidden = on;
		}
		if ( submit ) {
			submit.disabled = on ? false : ! ( checkbox && checkbox.checked );
		}
		if ( optedin ) {
			optedin.hidden = ! on;
		}
	}

	// "Use a different email": reveal the field, clear it, and hide the summary.
	document.addEventListener( 'click', function ( event ) {
		var target = event.target;
		if ( ! target || ! target.closest ) {
			return;
		}
		var change = target.closest( '[data-ild-gate-change]' );
		if ( ! change ) {
			return;
		}
		event.preventDefault();
		var form = change.closest( '.ild-gate__form' );
		if ( ! form ) {
			return;
		}
		var known = form.querySelector( '[data-ild-gate-known]' );
		var field = form.querySelector( '.ild-gate__field' );
		var input = form.querySelector( '.ild-gate__email' );
		if ( known ) {
			known.hidden = true;
		}
		if ( field ) {
			field.hidden = false;
		}
		if ( input ) {
			input.value = '';
			input.focus();
		}
		// A new address is a fresh opt-in: bring the consent box back.
		applyRememberedConsent( form, false );
	} );

	// Enable the submit button only while the consent box is ticked, and show
	// the reason it is disabled rather than failing silently.
	document.addEventListener( 'change', function ( event ) {
		var box = event.target;
		if ( ! box || ! box.matches || ! box.matches( '[data-ild-gate-consent]' ) ) {
			return;
		}
		var form = box.closest( '.ild-gate__form' );
		if ( ! form ) {
			return;
		}
		var button = form.querySelector( '[data-ild-gate-submit]' );
		var note = form.querySelector( '[data-ild-gate-note]' );
		if ( button ) {
			button.disabled = ! box.checked;
		}
		if ( note ) {
			note.hidden = box.checked;
		}
	} );

	function showGateError( form, message ) {
		var el = form.querySelector( '[data-ild-gate-error]' );
		if ( el ) {
			el.textContent = message;
			el.hidden = false;
		}
	}

	function submitGate( form ) {
		var gate = form.closest( '[data-ild-gate]' );
		var button = form.querySelector( '[data-ild-gate-submit]' );
		var source = form.querySelector( '[data-ild-gate-source]' );
		var errorEl = form.querySelector( '[data-ild-gate-error]' );

		if ( source ) {
			source.value = window.location.href;
		}
		if ( errorEl ) {
			errorEl.hidden = true;
			errorEl.textContent = '';
		}
		if ( button ) {
			button.disabled = true;
		}

		// The gate form was injected after the page loaded, so refresh its nonce
		// from the live one before sending (the fetch has long since resolved by
		// the time the gate is on screen).
		var gateNonce = form.querySelector( 'input[name="ild_gate_nonce"]' );
		if ( gateNonce && freshNonces.gate ) {
			gateNonce.value = freshNonces.gate;
		}

		// The address being sent to, so it can be remembered on this device once
		// the send succeeds.
		var emailField = form.querySelector( '.ild-gate__email' );
		var sentTo = emailField ? emailField.value : '';

		var data = new FormData( form );
		data.append( 'action', settings.gateAction );

		fetch( settings.ajaxUrl, {
			method: 'POST',
			credentials: 'same-origin',
			body: data
		} )
			.then( function ( response ) { return response.json(); } )
			.then( function ( payload ) {
				if ( payload && payload.success && payload.data && typeof payload.data.html === 'string' && gate && gate.parentNode ) {
					// Remember the address and the opt-in for next time (this browser
					// only), so a returning visitor is not asked to consent again.
					rememberEmail( sentTo );
					rememberConsent();
					// Replace the gate with the now-unlocked breakdown, and move
					// focus to it so it is announced.
					var holder = document.createElement( 'div' );
					holder.innerHTML = payload.data.html;
					var node = holder.firstElementChild;
					if ( node ) {
						gate.parentNode.replaceChild( node, gate );
						node.setAttribute( 'tabindex', '-1' );
						node.focus();
					}
					return;
				}
				var messages = settings.gateMessages || {};
				var message = ( payload && payload.data && payload.data.message ) ? payload.data.message : ( messages.network || '' );
				showGateError( form, message );
				if ( button ) {
					button.disabled = false;
				}
			} )
			.catch( function () {
				var messages = settings.gateMessages || {};
				showGateError( form, messages.network || '' );
				if ( button ) {
					button.disabled = false;
				}
			} );
	}

	// Submit the form over AJAX. One document-level listener covers every tool,
	// now or added later.
	document.addEventListener( 'submit', function ( event ) {
		var form = event.target;
		if ( ! form || ! form.classList ) {
			return;
		}

		// The email gate has its own submission.
		if ( form.classList.contains( 'ild-gate__form' ) ) {
			event.preventDefault();
			submitGate( form );
			return;
		}

		if ( ! form.classList.contains( 'ild-form' ) ) {
			return;
		}

		event.preventDefault();

		var tool = toolOf( form );
		if ( ! tool ) {
			return;
		}

		var results = tool.querySelector( '.ild-results' );
		var loading = tool.querySelector( '.ild-loading' );
		var netError = tool.querySelector( '.ild-error--network' );

		// Reset the regions: clear the last result, hide the network error, show
		// the loading message, and mark the tool busy for assistive tech.
		if ( netError ) {
			netError.hidden = true;
		}
		if ( results ) {
			results.innerHTML = '';
		}
		if ( loading ) {
			loading.hidden = false;
		}
		tool.setAttribute( 'aria-busy', 'true' );

		// Make sure a live nonce is in place before sending — this is the first
		// submit, so the page-load fetch may not have resolved yet.
		ensureNonces().then( function () {
			if ( freshNonces.analyse ) {
				var nf = form.querySelector( 'input[name="ild_nonce"]' );
				if ( nf ) {
					nf.value = freshNonces.analyse;
				}
			}

		// Send the whole form (list, product name, nonce, honeypot) plus the action.
		var data = new FormData( form );
		data.append( 'action', 'ild_analyse' );

		fetch( settings.ajaxUrl, {
			method: 'POST',
			credentials: 'same-origin',
			body: data
		} )
			.then( function ( response ) {
				return response.json();
			} )
			.then( function ( payload ) {
				if ( loading ) {
					loading.hidden = true;
				}
				tool.removeAttribute( 'aria-busy' );

				// The server always renders a fragment (result, empty or error).
				if ( payload && payload.data && typeof payload.data.html === 'string' ) {
					if ( results ) {
						results.innerHTML = payload.data.html;

						// If the reading carries the email form, show the remembered
						// address (this device) with a link to change it.
						initGateForm( results.querySelector( '.ild-gate__form' ) );

						// Move focus to the result so keyboard users land on it and
						// screen readers announce it (the region is aria-live too).
						var focusable = results.querySelector( '.ild-result, .ild-state' );
						if ( focusable ) {
							focusable.setAttribute( 'tabindex', '-1' );
							focusable.focus();
						}
					}
				} else if ( netError ) {
					netError.hidden = false;
				}
			} )
			.catch( function () {
				// The request itself failed (offline, server error). Show the
				// last-resort message rather than leaving the spinner up.
				if ( loading ) {
					loading.hidden = true;
				}
				tool.removeAttribute( 'aria-busy' );
				if ( netError ) {
					netError.hidden = false;
				}
			} );
		} );
	} );
} )();
